Template for students -
Silesian University of Technology in Gliwice
Faculty of Automatic Control, Electronics and Computer Science.

Based on: "VIBOT Master Thesis Template" (Robert Martí 
VIBOT.org, March 2008)



Zawartość szablonu:

- folder Rozdziały - folder zawierający kolejne rozdziały (najlepiej pisać każdy rozdział w osobnym pliku .tex)

- folder figures - folder zawierający kolejne pliki (jeśli dołączamy liczne rysunki, dobrze utworzyć osobne foldery dla poszczególnych rozdziałów)

- appendix.tex - plik zawierający dodatki umieszczane na końcu pracy

- header.tex - plik definujący stronę tytułową pracy oraz ewentualny abstrakt (Streszczenie)

- thesis.tex - główny plik; zawiera ustawienia dokumentu, pozwala na ładowanie pakietów oraz dołączanie plików

- Refs.bib: an example of bib file for building bibliography with bibtex.